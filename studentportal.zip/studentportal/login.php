<?php

if(!isset($_SESSION)){
    session_start();
}

include_once("connections/connection.php");
$con = connection();

if(isset($_POST['login'])){

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM student_users WHERE username = '$username' AND password = '$password'";
   $user = $con->query($sql) or die ($con->error);
   $row = $user->fetch_assoc();
   $total = $user->num_rows;


   if($total>0){
    $_SESSION['UserLogin'] = $row['username'];
    $_SESSION['Access'] = $row['access'];
    echo header("Location: dash.php");
   }else{
    echo "<div class='message warning'>No User Found.</div>";
   }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" contents="width=device-width, initial-scale1.0">
    <meta http-equiv="X-UA-Compatible" contents="ie=edge">
    <title>STUDENT PORTAL</title>
    <link rel="stylesheet" href="css/style.css">

</head>
<body id="formlogin">

<div class="login-container">
    <h2>Cavite State University</h2>
    <h3>Bacoor Campus</h3>

    <br/>
    <div class="form-logo">
        <img src="img/cvsu.png" alt="">
    </div>

    <form action="" method="post">

    <div class="form-element">
        <label> Username</label>
        <input type="text" name="username" id="username" autocomplete="off" placeholder="Enter Username" required>
    </div>

    <div class="form-element">
        <label>Password</label>
        <input type="password" name="password" id="password" autocomplete="off" placeholder="Enter Password" required>
    </div>

    <div class="log">
    <button type="submit" name="login">Login</button>
    </div>

    </form>
</div>

</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Header</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<header>
  <a href="dash.php"> Admin Dashboard</a> | <a href="sched.php">Subject Schedule</a>  |  <a href="grade.php">Grade Viewer</a>  |   <a href="checklist.php">Checklist Recommendation</a>  | <a href="credentials.php">Request Credentials </a> |  <a href="files.php">Printable PDF File </a> |  <a href="login.php">Log In</a> | <a href="logout.php">Log Out</a> </header>

</body>
</html>





                
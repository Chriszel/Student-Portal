<?php

include_once("connections/connection.php");
$con = connection();
$id = $_GET['ID'];

    $sql = "SELECT * FROM bsit WHERE id = '$id'";
     $students = $con->query($sql) or die ($con->error);
     $row = $students->fetch_assoc();

    if(isset($_POST['submit'])){
       
        $fname = $_POST['firstname'];
        $mname = $_POST['middlename'];
        $lname = $_POST['lastname'];
        $snum = $_POST['studentnumber'];
        $bday = $_POST['birthday'];
        $gend = $_POST['gender'];

        $sql = "UPDATE bsit SET first_name = '$fname', middle_name = '$mname', last_name = '$lname', stud_num = '$snum',
        birth_day = '$bday', gender = '$gend' WHERE id = '$id'";
        
        $con->query($sql) or die($con->error);
        
        echo header("location: details.php?ID=".$id);

    }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" contents="width=device-width, initial-scale1.0">
    <meta http-equiv="X-UA-Compatible" contents="ie=edge">
    <title>STUDENT PORTAL</title>
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
    <form action="" method="post">

       <label>First Name</label>
       <input type="text" name="firstname" id="firstname" value="<?php echo $row['first_name'];?>">

       <label>Middle Name</label>
       <input type="text" name="middlename" id="middlename" value="<?php echo $row['middle_name'];?>">


       <label>Last Name</label>
       <input type="text" name="lastname" id="lastname" value="<?php echo $row['last_name'];?>">

       <label>Student Number</label>
       <input type="text" name="studentnumber" id="studentnumber" value="<?php echo $row['stud_num'];?>">

       <label>Birth Date</label>
       <input type="text" name="birthday" id="birthday" value="<?php echo $row['birth_day'];?>">


       <label>Gender</label>
       <select name="gender" id="gender">
        <option value="Male" <?php echo ($row['gender'] == "Male")? 'selected' : '';?> >Male</option>
        <option value="Female" <?php echo ($row['gender'] == "Female")? 'selected' : '';?>>Female</option>
        </select>
        <br/>
        <br/>
       <input type="submit" name="submit" value="UPDATE">

    </form>

</body>
</html>
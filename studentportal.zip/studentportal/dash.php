<?php 
include 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
   
    <link rel="stylesheet" type="text/css" href="style.css">
<style>

.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px;
  font-size: 16px;
  border-radius: 10px;

}

.dropdown {
  position:relative;
  display: inline-block;
  
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
<body>
<br>
<div class="form-logo">
        <img src="img/cvsu.png" alt="">
    </div>
<h1> <b> <font color="green">   WELCOME TO <br> CAVITE STATE UNIVERSITY BACOOR CAMPUS STUDENT PORTAL </font></b></h1>
<br>

<div class="dropdown">
  <button class="dropbtn">BSIT</button>
  <div class="dropdown-content">
    <a href="bsit1.php"> First Year </a>
    <a href="bsit2.php">Second Year</a>
    <a href=" ">Third Year</a>
    <a href = "bsit4.php"> Fourth Year </a>
     
  </div>
</div>

<div class="dropdown">
  <button class="dropbtn">BSCS</button>
  <div class="dropdown-content">
    <a href="#">First Year</a>
    <a href="#">Second Year</a>
    <a href="#">Third Year</a>
    <a href="#">Fourth Year</a>

  </div>
</div>

<div class="dropdown">
  <button class="dropbtn">BSCrim</button>
  <div class="dropdown-content">
    <a href="#">First Year</a>
    <a href="#">Second Year</a>
    <a href="#">Third Year</a>
    <a href="#">Fourth Year</a>
  </div>
</div>

<div class="dropdown">
  <button class="dropbtn">BSHRM/HM</button>
  <div class="dropdown-content">
    <a href="#">First Year</a>
    <a href="#">Second Year</a>
    <a href="#">Third Year</a>
    <a href="#">Fourth Year</a>
  </div>
</div>

<div class="dropdown">
  <button class="dropbtn">BSE</button>
  <div class="dropdown-content">
    <a href="#">First Year</a>
    <a href="#">Second Year</a>
    <a href="#">Third Year</a>
    <a href="#">Fourth Year</a>
  </div>
</div>

<div class="dropdown">
  <button class="dropbtn">BSBM</button>
  <div class="dropdown-content">
    <a href="#">First Year</a>
    <a href="#">Second Year</a>
    <a href="#">Third Year</a>
    <a href="#">Fourth Year</a>
  </div>
</div>

<div class="dropdown">
  <button class="dropbtn">BSPYC</button>
  <div class="dropdown-content">
    <a href="#">First Year</a>
    <a href="#">Second Year</a>
    <a href="#">Third Year</a>
    <a href="#">Fourth Year</a>
  </div>
</div>

<div class="dropdown">
  <button class="dropbtn">Irreg.</button>
  <div class="dropdown-content">
    <a href="#">First Year</a>
    <a href="#">Second Year</a>
    <a href="#">Third Year</a>
    <a href="#">Fourth Year</a>
     
  </div>
</div>

<section class="home-section">
    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Student BSIT</div>
            <div class="number">610</div>
            <div class="indicator">
      
              <span class="text">Up from Second Semester 2022</span>
            </div>
          </div>
        
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Student BSCS</div>
            <div class="number">285</div>
            <div class="indicator">
       
              <span class="text">Up from Second Semester 2022</span>
            </div>
          </div>
        
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Student BSC</div>
            <div class="number">637</div>
            <div class="indicator">
            
              <span class="text">Up from Second Semester 2022</span>
            </div>
          </div>
          
        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Student BSHRM</div>
            <div class="number">1030</div>
            <div class="indicator">
         
              <span class="text">Up from Second Semester 2022</span>
            </div>
          </div>

           </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Student BSE </div>
            <div class="number">408</div>
            <div class="indicator">
         
              <span class="text">Up from Second Semester 2022</span>
            </div>
          </div>

           </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Student BSBM</div>
            <div class="number">1156</div>
            <div class="indicator">
         
              <span class="text">Up from Second Semester 2022</span>
            </div>
          </div>

           </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Student BSPYC</div>
            <div class="number">511</div>
            <div class="indicator">
         
              <span class="text">Up from Second Semester 2022</span>
            </div>
          </div>


               </div>
          <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Faculty Teachers</div>
            <div class="number">167</div>
            <div class="indicator">
         
              <span class="text">Up from Second Semester 2022</span>
            </div>
          </div>

 </div>
            <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Subjects</div>
            <div class="number">150</div>
            <div class="indicator">
         
              <span class="text">Up from Second Semester 2022</span>
            </div>
          </div>

 </div>
            <div class="box">
          <div class="right-side">
            <div class="box-topic">Total Students</div>
            <div class="number">4637</div>
            <div class="indicator">
         
              <span class="text">Up from Second Semester 2022</span>
            </div>
          </div>


    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>
</div>
</body>
</html>